<!DOCTYPE html>
<html>

<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <!-- CSS only -->

</head>

<body><br> <br> <br>
  <div class="container">
    <div class="row col-md-6 col-md-offset-3">
      <div class="panel panel-primary">
        <div class="panel-heading text-center">
          <h1><strong>Login</strong> </h1>
        </div>
        <div class="panel-body">
          <form method="post" id="form-login">
            <p class="form-group"><input autofocus type="text" id="username" value="" placeholder="Username"  class="form-control" required></p>
            <p class="form-group"><input type="password" id="password" value="" placeholder="Password" class="form-control"  required></p>
            <p class="remember_me">
              <label>
                <input type="checkbox" name="remember_me" id="remember_me">
                Remember me on this computer
              </label>
            </p>
            <p class="submit"><input type="submit" name="commit" value="Login" class="btn btn-info"></p>
          </form>


        </div>

      </div>
    </div>
  </div>
  <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


  </div>
</body>

<script src="assets/js/jquery-3.1.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/login.js"></script>

</html>