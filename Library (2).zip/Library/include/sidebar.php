<div id="wrapper">


<nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <i class="fa fa-bars"></i> 
                </button>
                <a class="navbar-brand" href="index-2.html">library</a>
            </div>
         
            <ul class="nav navbar-top-links navbar-right">
               
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                    <?php echo $_SESSION['EmailId'] ?>
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                   
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="change_profile.php"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="change_password.php"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                   
                  
                    <!-- /.dropdown-user -->
                </li>
                
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="home.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="Book_List.php"><i class="fa fa-book"></i> Book List</a>
                    </li>
					<li>
                        <a href="User_Issued_Book.php"><i class="fa fa-bars"></i> Issued Books</a>
                    </li>
                    <li class="dropdown">
                        <a href="#"><i class="dropdown-toggle fa fa-user" data-toggle="dropdown" aria-expanded="false"></i> Account<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level dropdown-menu ">
                           
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                           
                        </ul>
                    </li>


                   

                </ul>

            </div>

        </nav>

        </div>