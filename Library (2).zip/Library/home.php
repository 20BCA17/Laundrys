<?php
include "auth.php";
include "include/header.php";
include "include/sidebar.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>

</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            USER DASHBOARD
                        </h1>
                    </div>
                   

                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">



                                        <div class="row">
                                            <div class="col-md-3 col-sm-12 col-xs-12">
                                                <div class="panel panel-primary text-center no-boder bg-color-green">
                                                    <div class="panel-left pull-left green">
                                                        <i class="fa fa-bars fa-5x"></i>

                                                    </div>
                                                    <div class="panel-right pull-right">
                                                        <h3>8</h3>
                                                        <a href="#"> <strong>Book Issued</strong></a>

                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3 col-sm-12 col-xs-12">
                                                <div class="panel panel-primary text-center no-boder bg-color-blue">
                                                    <div class="panel-left pull-left blue">
                                                        <i class="fa fa-recycle fa-5x "></i>



                                                    </div>
                                                    <div class="panel-right pull-right">
                                                        <h3>8</h3>
                                                        <a href="#"> <strong>Book Not Returned Yet</strong></a>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>
<?php
include "include/script.php";
?>