
<html>

<head>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">

</head>

<body><br> <br> <br>


	<div class="container">
		<div class="row col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading text-center">
					<h1>Change Password</h1>
				</div>
				<div class="panel-body">

					<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" class="text-center" id="cng">
						<div class="cng">

							<div class="form-group col-lg-10 " align="left">
								<label for="Old Password:">Old Password:</label>
								<input type="password" name="password" placeholder="Current password" class="form-control"  >
							</div>

							<div class="form-group col-lg-10" align="left">
								<label for="new Password:">new Password:</label>
								<input type="password" name="newpassword" placeholder="New password"  class="form-control" required data-parsley-length="[8, 16]" data-parsley-trigger="keyup">
							</div>
							<div class="form-group col-lg-10" align="left"> 
								<label for="confirm Password:">confirm Password:</label>
								<input type="password" name="confpassword" placeholder=" confirm password"  class="form-control" data-parsley-equalto="#password" data-parsley-trigger="keyup" required>
							</div>

							<div class="form-group col-md-3">
								<!-- <button  class="btn btn-danger" >Update Password</button> <br> -->
								<button class="btn btn-info" name="submit" type="submit"><i class=" fa fa-refresh "></i> Update Password </button>
								
							</div>

						</div>

				</div>
			</div>
		</div>
		<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


		</div>





		</form> <br>&nbsp;&nbsp;&nbsp;

		<br>


	</div>

	</div>
	

	</div>

</body>

</html>
