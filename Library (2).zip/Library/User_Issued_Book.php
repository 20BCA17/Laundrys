<?php
include "auth.php";
include "include/header.php";
include "include/sidebar.php";
?>
<html>

<head>
    <style>
        table,
        th,
        td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
</head>

<body>
    <div id="wrapper">
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Book List
                        </h1>
                    </div>


                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">


                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Book Name</th>
                                                        <th>Category</th>
                                                        <th>Author</th>
                                                        <th>Accession Number</th>
                                                        <th>Price</th>
                                                        <th>Bill No</th>
                                                        <th>Bill Date</th>
                                                        <th>Publisher</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>

                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>

                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>

                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Suraj Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>
                                                    <tr class="odd gradeX">
                                                        <td>1</td>
                                                        <td>Java</td>
                                                        <td>Coding</td>
                                                        <td>Nitin Dube</td>
                                                        <td>1</td>
                                                        <td>₹ 1,000 </td>
                                                        <td>17</td>
                                                        <td>20/5/2003</td>
                                                        <td>Songadh</td>
                                                        <td>Active</td>
                                                    </tr>


                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>

<?php
include "include/script.php";
?>