<?php
session_start();
// session_destroy();
if(empty($_SESSION['EmailId'])){
    header("Location:login.php");
}
// }else{

// }
?>