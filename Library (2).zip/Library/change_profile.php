
<html>

<head>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">

</head>

<body><br> <br> <br>


	<div class="container">
		<div class="row col-md-6 col-md-offset-3">
			<div class="panel panel-primary">
				<div class="panel-heading text-center">
					<h1>Change Password</h1>
				</div>
				<div class="panel-body">

					<form class="text-center">
						<div class="cng">

							<div class="form-group col-lg-12" align="left">
								<label for="Mobile No">Mobile No</label>
								<input type="text" name=""  class="form-control" >
							</div>

							

							<div class="form-group col-md-3">
								<!-- <button  class="btn btn-danger" >Update Password</button> <br> -->
								<button class="btn btn-info" name="submit" type="submit"><i class=" fa fa-refresh "></i> Update </button>
								
							</div>

						</div>

				</div>
			</div>
		</div>
		<div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


		</div>





		</form> <br>&nbsp;&nbsp;&nbsp;

		<br>


	</div>

	</div>
	

	</div>

</body>

</html>
