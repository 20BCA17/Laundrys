<?php

include "include/icon.php";

?>

<?php
 if (isset($_POST["reg"])) {
    include 'db.php';
    // When form submitted, insert values into the database.
  
        // removes backslashes
        $StudentId = stripslashes($_REQUEST['StudentId']); 
        $StudentId = mysqli_real_escape_string($con, $StudentId);

        $FullName    = stripslashes($_REQUEST['FullName']);
        $FullName    = mysqli_real_escape_string($con, $FullName);

        $EmailId = stripslashes($_REQUEST['EmailId']);
        $EmailId = mysqli_real_escape_string($con, $EmailId);

        $MobileNumber = stripslashes($_REQUEST['MobileNumber']);
        $MobileNumber = mysqli_real_escape_string($con, $MobileNumber);

        $Password = stripslashes($_REQUEST['Password']);
        $Password = mysqli_real_escape_string($con, $Password);


        $query    = "INSERT into `tblstudents` (StudentId  ,FullName, EmailId, MobileNumber , Password)
        VALUES ('$StudentId','$FullName',  '$EmailId', '$MobileNumber', '" . md5($Password) . "')";
                     
        $result   = mysqli_query($con, $query);
        if ($result) {
            
            header("Location:login.php");
        } else {
            echo "failed";
        }


    }
    
?>
<!DOCTYPE html>
<html>

<head>

    <title>Registration Page</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous" />
</head>

<body><br><br>
    <div class="container">
        <div class="row col-md-6 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <h1> <strong>SINGUP</strong></h1>
                </div>
                <div class="panel-body">
                    <form  method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">

                        <div class="form-group">
                            <label for="StudentId">Student Id / Faculty Id</label>
                         
                            <input type="text"  class="form-control" placeholder="enter id" name="StudentId" id="myInput"/>
                        </div>
                        <div class="form-group">
                            <label for="FullName">Full Name</label>
                            <input type="text" class="form-control"  name="FullName" required placeholder="SURNAME FRISTNAME LASTNAME" />
                        </div>
                        <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="email" class="form-control" id="result" name="EmailId" required />
                        </div>

                        <script>
                            $vtcbb = "@vtcbb.edu.in";
                            $vtcbcsr = "@vtcbcsr.edu.in"


                            $("#myInput").keyup(function() {
                                $userValue = $(this).val();
                                if ($userValue < "21") {
                                    $resultValue = $userValue + $vtcbb;
                                    $("#result").val($resultValue);

                                } else {
                                    $resultValue = $userValue + $vtcbcsr;
                                    $("#result").val($resultValue);

                                }

                            });
                        </script>

                        <div class="form-group">
                            <label for="number">Mobile Number</label>
                            <input type="text" class="form-control" name="MobileNumber" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" class="input_text" value="" required />
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="Password" id="password" placeholder="Password" required data-parsley-length="[8, 16]" data-parsley-trigger="keyup" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label for="cpassword">Confirm Password</label>
                            <input type="password"  id="confirm_password" placeholder="Confirm Password" data-parsley-equalto="#password" data-parsley-trigger="keyup" required class="form-control" />
                        </div>


                        <input type="submit" class="btn btn-primary" name="reg" value="Register" />
                        <a href="login.php">sign in</a>
                    </form>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
