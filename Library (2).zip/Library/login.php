<?php
include "include/icon.php";
?>

<?php session_start();
if (isset($_SESSION['EmailId'])) {
    header("Location: home.php");
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <!-- CSS only -->

</head>

<body><br> <br> <br>
    <div class="container">
        <div class="row col-md-6 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <h1><strong>Login</strong> </h1> 
                </div>
                <div class="panel-body">
                    <form action="" method="POST" id="login">

                        <div class="form-group">
                            <label for="EmailId">EmailId</label>
                            <input type="text" class="form-control" id="EmailId" name="EmailId" placeholder="EmailId Address/Mobile Number" required data-parsley-type="EmailId">
                        </div>
                        <div class="form-group">
                            <label for="Password">Password</label>
                            <input type="Password" class="form-control" id="Password" name="Password"  placeholder="Password" required/>
                        </div>
                       <div class="form-group ">
                              &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href="" style="float: right;"> Forgot Password ?</a>
                       </div >
                       <div class="form-group " >
                        <button class="btn btn-primary" type="submit" name="submit"> Login Now</button>
                        

                       </div>

                        Don't have an account ?<a href="registration.php">Sign Up</a>
                    </form>

                 
                </div>

            </div>
        </div>
    </div>
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">


    </div>
</body>

</html>


<?php
                if (isset($_POST["submit"])) {
                    include 'db.php';
                    $EmailId = mysqli_real_escape_string($con, $_POST['EmailId']);
                    $Password = mysqli_real_escape_string($con, $_POST['Password']);
                    $Password = md5($Password);

                    $sql = "SELECT * FROM tblstudents WHERE EmailId = '{$EmailId}' AND Password = '{$Password}'"; 
                    // echo $sql; die;
                    $result = mysqli_query($con, $sql) or die("query failed");
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                        // session_start();
                        $_SESSION["EmailId"] = $row['EmailId'];
                        $_SESSION["Password"] = $row['Password'];
                    
                        header("Location: home.php");
                        // echo '<div class="alert alert-success>Welcome to dashboard</div>';
                        }
                } else {
                    
               
                    echo "<script>alert('EmailId or Password Not Matched ')
                    window.location.href = 'login.php';
                  </script>";
                }
            }
?>
